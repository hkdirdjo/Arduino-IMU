# BLAforQUAT
A BasicLinearAlgebra-based quaternion library 

Hello traveller! 

I wrote this library while working on a Teensy-based Inertial Navigation System using a Kalman Filter. 
I was using BasicLinearAlgebra for all of my other steps and didn't want to have to swap back and forth with another data format used by some other quaternion library.
The result is BLAforQUAT (a horrific name if I ever heard one) - an incompletely featured quaternion library that ONLY deals in BLA matrices.

If this repo garners any interest I may come back and add some examples and more methods - but for now it does all I need it to and I have other irons in the fire.

Enjoy!
