# Vicon MAVLink Gateway

This script produces GLOBAL_VISION_POSITION_ESTIMATE, GPS_INPUT and
GPS_GLOBAL_ORIGIN messages based on data from a Vicon indoor
positioning system.

It uses the pyvicon library from here:

  https://github.com/MathGaron/pyvicon

which is a python wrapper around the Vicon SDK.
