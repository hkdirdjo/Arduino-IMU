## 1.0.3.dev [28 Oct 2019]

Typographic update: use `this` in class, and `<XXX.h>` instead of `"XXX.h"` in includes

README simplification

## 1.0.2 [24 Sep 2019]

Small update, mainly `library.properties` for Arduino library manager

## 1.0.1 [30 Aug 2019]

Improved SRAM memory saving thanks to `Symmetric` matrices for covariances

Possibility to use `Symmetric`, `SkewSymmetric`, `TriangulerSup`, `TriangularInf` matrices for `F`

## 1.0.0 [24 Aug 2019]

Creation of the Kalman library
